const COLORS = {
    homeBackgroud: '#E8E8E8',
    noteBackground: '#fff',
    notes:'#fff',
    header: '#ffc917',
    headerButtons:'#000',
    addButton:'#ffc917',
    loading:'#0000ff',
    searchBar:'#ffff'
}

export default COLORS;